set -eu
MAI_BIN="/home/takeshi/Documents/Codex/2026-10-16/task-2/integration/target/release/mai"
DEMO_ROOT=$(mktemp -d /tmp/mai-demo.XXXXXX)
mkdir "$DEMO_ROOT/source"
git -C "$DEMO_ROOT/source" init -b main
git -C "$DEMO_ROOT/source" config user.name 'Demo maintainer'
git -C "$DEMO_ROOT/source" config user.email 'demo@example.invalid'
cat > "$DEMO_ROOT/source/gate.sh" <<'GATE'
set -eu
test "$(cat "$MAI_CANDIDATE_ROOT/message.txt")" = 'hello'
GATE
cat > "$DEMO_ROOT/source/mai.toml" <<'POLICY'
version = 1
[check]
program = "sh"
script = "gate.sh"
timeout_ms = 5000
output_tail_bytes = 1024
[validators]
slots = 1
port_base = 31000
ports_per_slot = 10
POLICY
printf 'hello\n' > "$DEMO_ROOT/source/message.txt"
git -C "$DEMO_ROOT/source" add .
git -C "$DEMO_ROOT/source" commit -m 'Add explicit demo gate'
"$MAI_BIN" init "$DEMO_ROOT/project" --from "$DEMO_ROOT/source" --json
"$MAI_BIN" status "$DEMO_ROOT/project" --json
"$MAI_BIN" workspace "$DEMO_ROOT/project" alice "$DEMO_ROOT/alice" --json
"$MAI_BIN" workspace "$DEMO_ROOT/project" bob "$DEMO_ROOT/bob" --json
BASE=$(git --git-dir="$DEMO_ROOT/project/authority.git" rev-parse refs/heads/trunk)
"$MAI_BIN" validator run "$DEMO_ROOT/project" "$BASE" --json
# Enable durable receipt with explicit example limits.
"$MAI_BIN" receive enable "$DEMO_ROOT/project" --max-input-bytes 10485760 --max-file-bytes 1048576 --max-changed-files 100 --json
git -C "$DEMO_ROOT/alice" config user.name 'Demo Alice'
git -C "$DEMO_ROOT/alice" config user.email 'alice@example.invalid'
printf 'parent work\n' > "$DEMO_ROOT/alice/parent.txt"
git -C "$DEMO_ROOT/alice" add parent.txt
git -C "$DEMO_ROOT/alice" commit -m 'Parent change'
PARENT=$(git -C "$DEMO_ROOT/alice" rev-parse HEAD)
git -C "$DEMO_ROOT/alice" push -o agent=alice mai HEAD:refs/for/main
printf 'dependent work\n' > "$DEMO_ROOT/alice/child.txt"
git -C "$DEMO_ROOT/alice" add child.txt
git -C "$DEMO_ROOT/alice" commit -m 'Dependent child change'
CHILD=$(git -C "$DEMO_ROOT/alice" rev-parse HEAD)
git -C "$DEMO_ROOT/alice" push -o agent=alice mai HEAD:refs/for/main
"$MAI_BIN" show "$DEMO_ROOT/project" "alice-$PARENT" --generation 1 --json
"$MAI_BIN" show "$DEMO_ROOT/project" "alice-$CHILD" --generation 1 --json
"$MAI_BIN" integrate "$DEMO_ROOT/project" "alice-$PARENT" --mode textual --wait-seconds 60 --json
"$MAI_BIN" integrate "$DEMO_ROOT/project" "alice-$CHILD" --mode textual --wait-seconds 60 --json
"$MAI_BIN" show "$DEMO_ROOT/project" "alice-$PARENT" --generation 1 --json
"$MAI_BIN" show "$DEMO_ROOT/project" "alice-$CHILD" --generation 1 --json
"$MAI_BIN" workspace "$DEMO_ROOT/project" fresh "$DEMO_ROOT/fresh" --json
test -f "$DEMO_ROOT/fresh/parent.txt"
test -f "$DEMO_ROOT/fresh/child.txt"
test "$(git -C "$DEMO_ROOT/alice" rev-parse HEAD)" = "$CHILD"
"$MAI_BIN" stop "$DEMO_ROOT/project" --json
printf 'Disposable demo retained at %s\n' "$DEMO_ROOT"
